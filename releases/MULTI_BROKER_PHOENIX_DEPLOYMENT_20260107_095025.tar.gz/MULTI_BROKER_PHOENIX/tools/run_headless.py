"""Small headless runner used by tools/start_headless.sh

Runs a minimal loop that polls configured connectors for prices and executes
strategy-driven test-ordering logic in PAPER mode.

CANARY MODE: When CANARY_MODE=true, runs in ultra-conservative mode with:
- Slower polling (30s default)
- Verbose narration of every action
- Lower risk limits
- Detailed logging for monitoring
"""
from __future__ import annotations
import os
import time
from typing import List, Optional
import argparse
from datetime import datetime


from multi_broker_phoenix.risk.risk_manager import RiskManager
from multi_broker_phoenix.strategies.base import get_strategy
from multi_broker_phoenix.engines.paper_engine import PaperEngine
from multi_broker_phoenix.brokers.coinbase_safe_connector import CoinbaseSafeConnector as CoinbaseConnector
from multi_broker_phoenix.brokers.ibkr_connector import IBKRConnector

try:
    from multi_broker_phoenix.brokers.oanda_connector import OANDAConnector
except Exception:
    OANDAConnector = None

# Import AI Hive
try:
    import sys
    hive_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(__file__))), 'hive_real')
    if hive_path not in sys.path:
        sys.path.insert(0, hive_path)
    from api_ai_hive import get_api_ai_vote
    AI_HIVE_AVAILABLE = True
except Exception as exc:
    AI_HIVE_AVAILABLE = False
    print(f'AI Hive not available: {exc}')



def _symbols_from_env() -> List[str]:
    # Coinbase uses hyphen format (BTC-USD), OANDA uses underscore (EUR_USD)
    s = os.getenv('FEED_SYMBOLS', 'BTC-USD,ETH-USD')
    return [x.strip() for x in s.split(',') if x.strip()]


def _is_canary_mode() -> bool:
    """Check if CANARY_MODE is enabled in environment."""
    return os.getenv('CANARY_MODE', 'false').lower() in ('true', '1', 'yes')


def _canary_log(msg: str):
    """Verbose logging for canary mode with timestamp."""
    timestamp = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    print(f"🐤 CANARY [{timestamp}] {msg}")


def _get_poll_interval() -> float:
    """Get polling interval, respecting canary mode override."""
    if _is_canary_mode():
        return float(os.getenv('CANARY_POLL_SECONDS', '30.0'))
    return float(os.getenv('HEADLESS_POLL_SECONDS', '2.0'))


def _get_max_risk_usd() -> float:
    """Get max risk per trade, respecting canary mode override."""
    if _is_canary_mode():
        return float(os.getenv('CANARY_MAX_RISK_USD', '10.0'))
    return float(os.getenv('MAX_RISK_USD_PER_TRADE', '30.0'))


def _choose_mode_interactive(options):
    """Present a simple numeric menu to choose a mode (TTY only). Returns mode key."""
    print('Select headless runner mode:')
    for idx, (k, desc) in enumerate(options.items(), start=1):
        print(f"  {idx}) {k} - {desc}")
    try:
        choice = input('Enter choice number (default 1): ').strip()
        if not choice:
            return list(options.keys())[0]
        i = int(choice) - 1
        return list(options.keys())[i]
    except Exception:
        return list(options.keys())[0]


def _trigger_autonomous_repair(error: Exception):
    """Trigger AI collective to diagnose and repair Hive failure."""
    import traceback
    
    print("\n🤖 INITIATING AUTONOMOUS REPAIR SYSTEM")
    print("   Connected AIs will collectively diagnose and patch the issue...")
    
    # Check if autonomous mode enabled
    if os.getenv('HIVE_AUTONOMOUS_REPAIR', 'false').lower() != 'true':
        print("   ⚠️  Autonomous repair DISABLED (set HIVE_AUTONOMOUS_REPAIR=true)")
        print("   📧 Alert sent - manual intervention required")
        _log_repair_incident(error, "DISABLED", "Autonomous repair not enabled", False)
        return
    
    try:
        # Import repair module
        from hive_real.autonomous_repair import diagnose_and_repair
        
        # Get error details
        error_type = type(error).__name__
        error_msg = str(error)
        error_trace = traceback.format_exc()
        
        print(f"\n🔍 ERROR ANALYSIS:")
        print(f"   Type: {error_type}")
        print(f"   Message: {error_msg}")
        
        # Call AI collective for diagnosis and repair
        result = diagnose_and_repair(
            error_type=error_type,
            error_message=error_msg,
            stack_trace=error_trace
        )
        
        if result['success']:
            print(f"\n✅ REPAIR SUCCESSFUL")
            print(f"   {result['summary']}")
            _log_repair_incident(error, "SUCCESS", result['documentation'], True)
        else:
            print(f"\n❌ REPAIR FAILED")
            print(f"   {result['reason']}")
            _log_repair_incident(error, "FAILED", result['documentation'], False)
            
    except ImportError:
        print("   ⚠️  Autonomous repair module not found")
        print("   📧 Alert sent - manual intervention required")
        _log_repair_incident(error, "MODULE_MISSING", "Repair module not installed", False)
    except Exception as repair_error:
        print(f"   ⚠️  Repair system error: {repair_error}")
        _log_repair_incident(error, "REPAIR_ERROR", str(repair_error), False)


def _log_repair_incident(error: Exception, status: str, details: str, success: bool):
    """Log repair incident to file for human review."""
    import json
    from pathlib import Path
    
    log_dir = Path(os.path.dirname(os.path.dirname(__file__))) / 'hive_real' / 'repair_logs'
    log_dir.mkdir(exist_ok=True)
    
    incident = {
        'timestamp': datetime.now().isoformat(),
        'error_type': type(error).__name__,
        'error_message': str(error),
        'status': status,
        'success': success,
        'details': details
    }
    
    log_file = log_dir / f"repair_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
    with open(log_file, 'w') as f:
        json.dump(incident, f, indent=2)
    
    print(f"   📝 Incident logged: {log_file}")


def run_headless(mode: Optional[str] = None):
    canary_mode = _is_canary_mode()
    
    if canary_mode:
        _canary_log("🚨 CANARY MODE ACTIVE - Ultra-conservative monitoring enabled")
        _canary_log(f"Polling interval: {_get_poll_interval()}s (slower for safety)")
        _canary_log(f"Max risk per trade: ${_get_max_risk_usd()} (ultra-low)")
    
    print('Starting headless runner (minimal).')
    # Determine mode: CLI arg, env var, or interactive menu
    valid_modes = {
        'auto': 'Auto (prefer platform connectors where appropriate)',
        'multi-asset': 'All brokers: OANDA + IBKR + Coinbase (high-quality AI Hive filtering)',
        'platform-paper': 'Prefer platform paper connectors when available',
        'simulate': 'Simulate only (engine)',
        'oanda-only': 'Use OANDA only (filter by symbol eligibility)',
        'coinbase-only': 'Use Coinbase only',
        'ibkr-only': 'Use IBKR only',
    }
    env_mode = os.getenv('HEADLESS_MODE')
    chosen = mode or env_mode
    if not chosen and os.isatty(0):
        # interactive selection
        chosen = _choose_mode_interactive(valid_modes)
    if not chosen:
        chosen = 'auto'
    if chosen not in valid_modes:
        print(f'Invalid mode {chosen}, falling back to auto')
        chosen = 'auto'
    print(f'Headless mode: {chosen} ({valid_modes.get(chosen)})')
    
    if canary_mode:
        _canary_log(f"Selected mode: {chosen}")

    rm = RiskManager()
    engine = PaperEngine()
    symbols = _symbols_from_env()
    
    if canary_mode:
        _canary_log(f"Initializing connectors for symbols: {', '.join(symbols)}")
    
    coin = CoinbaseConnector(paper_mode=True, engine=engine)
    ibkr = IBKRConnector(paper_mode=True, engine=engine)
    oanda = None
    if OANDAConnector is not None and os.getenv('OANDA_API_TOKEN'):
        oanda = OANDAConnector(token=os.getenv('OANDA_API_TOKEN'), account_id=os.getenv('OANDA_ACCOUNT_ID'), base_url=os.getenv('OANDA_API_URL', 'https://api-fxpractice.oanda.com'), engine=engine)
        print('OANDA connector initialized')
        if canary_mode:
            _canary_log("OANDA connector available")
    else:
        print('OANDA connector unavailable or token missing; continuing with other connectors')
        if canary_mode:
            _canary_log("OANDA connector disabled/unavailable")

    strategy = get_strategy(os.getenv('DEFAULT_STRATEGY', 'holy_grail'))
    if canary_mode:
        _canary_log(f"Strategy loaded: {os.getenv('DEFAULT_STRATEGY', 'holy_grail')}")
    
    prices = {s: [] for s in symbols}

    try:
        loop_count = 0
        if canary_mode:
            _canary_log("🚀 Starting main loop - monitoring all activity")
        
        while True:
            loop_count += 1
            if canary_mode and loop_count % 10 == 1:  # Every 10th iteration
                _canary_log(f"Loop #{loop_count} - Health check OK")
            
            for sym in symbols:
                # poll each connector for a price
                price = None
                # Route based on mode or symbol pattern
                if chosen == 'coinbase-only' or (chosen in ('auto', 'multi-asset') and '-' in sym):
                    price = coin.fetch_live_price(sym)
                    if canary_mode and price:
                        _canary_log(f"📊 {sym} price: ${price:.2f} (Coinbase)")
                elif chosen == 'ibkr-only':
                    price = ibkr.get_last_price(sym)
                    if canary_mode and price:
                        _canary_log(f"📊 {sym} price: ${price:.2f} (IBKR)")
                elif oanda and ('_' in sym or chosen in ('oanda-only', 'multi-asset')):
                    price = oanda.get_last_price(sym)
                    if canary_mode and price:
                        _canary_log(f"📊 {sym} price: ${price:.2f} (OANDA)")
                else:
                    # fallback: try coin then ibkr
                    price = coin.fetch_live_price(sym) or ibkr.get_last_price(sym)
                    if canary_mode and price:
                        _canary_log(f"📊 {sym} price: ${price:.2f} (fallback)")
                
                if price is None:
                    if canary_mode:
                        _canary_log(f"⚠️  {sym} price unavailable - skipping")
                    continue
                prices[sym].append(price)
                if len(prices[sym]) > 200:
                    prices[sym] = prices[sym][-200:]
                cand = strategy.generate_candidate({'symbol': sym, 'platform':'HEADLESS', 'prices': prices[sym]})
                if not cand:
                    if canary_mode and loop_count % 10 == 1:
                        _canary_log(f"✋ {sym} - No signal generated")
                    continue
                
                if canary_mode:
                    _canary_log(f"🎯 {sym} SIGNAL: {cand.side} @ ${price:.2f} (confidence: {getattr(cand, 'confidence', 'N/A')})")
                
                # Decide target platform based on symbol if strategy did not set one
                platform_guess = 'OANDA' if '_' in sym else 'COINBASE' if '-' in sym else 'IBKR'
                try:
                    if not getattr(cand, 'platform', None):
                        cand.platform = platform_guess
                except Exception:
                    pass
                from multi_broker_phoenix.risk.trade_risk_gate import can_open_trade
                dec = can_open_trade(cand, account_equity=rm.state.equity_now or 100000.0, rm=rm)
                if not dec.allowed:
                    print(f"trade blocked: {dec.reason}")
                    if canary_mode:
                        _canary_log(f"🚫 Trade BLOCKED: {dec.reason}")
                    continue
                
                # AI Hive consensus check
                if AI_HIVE_AVAILABLE and os.getenv('ENABLE_AI_HIVE', 'false').lower() == 'true':
                    # Check for emergency bypass (manual override)
                    if os.getenv('HIVE_EMERGENCY_BYPASS', 'false').lower() == 'true':
                        print("⚠️  EMERGENCY BYPASS ACTIVE - Hive disabled by manual override")
                        if canary_mode:
                            _canary_log("⚠️  EMERGENCY BYPASS - Manual override active")
                    else:
                        try:
                            # Get recent prices for Hive analysis
                            recent_prices = []
                            try:
                                if '_' in sym:  # OANDA
                                    if oanda:
                                        prices_data = oanda.get_historical_data(sym, count=30)
                                        recent_prices = [float(p.get('mid', {}).get('c', 0)) for p in prices_data]
                                elif '-' in sym:  # Coinbase
                                    prices_data = coin.get_historical_data(sym, periods=30)
                                    recent_prices = [float(p) for p in prices_data]
                            except Exception:
                                recent_prices = [cand.entry] * 10  # Fallback to current price
                            
                            market_data = {'prices': recent_prices or [cand.entry]}
                            hive_result = get_api_ai_vote(sym, cand.side.upper(), cand.entry, market_data)
                            
                            if canary_mode:
                                _canary_log(f"🤖 AI Hive: {hive_result['vote']} (consensus: {hive_result.get('consensus', 0):.1%})")
                            
                            # Block if not approved
                            if hive_result['vote'] not in ['approve', 'execute']:
                                print(f"AI Hive blocked trade: {hive_result['reasoning']}")
                                if canary_mode:
                                    _canary_log(f"🚫 AI Hive BLOCKED: {hive_result['reasoning']}")
                                continue
                                
                        except Exception as hive_exc:
                            # CRITICAL FAILURE - Trigger self-healing
                            print(f"🚫 AI HIVE CRITICAL FAILURE - BLOCKING ALL NEW TRADES")
                            print(f"   Error: {hive_exc}")
                            if canary_mode:
                                _canary_log(f"🚨 CRITICAL: AI Hive failure - {hive_exc}")
                            
                            # Trigger autonomous diagnosis and repair
                            _trigger_autonomous_repair(hive_exc)
                            continue  # HALT - no trade execution on Hive failure
                
                sizing = rm.size_for_trade(cand, rm.state.equity_now or 100000.0, fee_pct=coin.fee_pct, slippage_pct=coin.slippage_pct)
                if not sizing.get('allowed'):
                    print('sizing rejected:', sizing.get('reason'))
                    if canary_mode:
                        _canary_log(f"🚫 Sizing REJECTED: {sizing.get('reason')}")
                    continue
                
                if canary_mode:
                    _canary_log(f"✅ Risk checks PASSED - Size: {sizing['size']} units")
                # Choose connector based on symbol/platform and prefer platform paper when available
                order = None
                try:
                    # Prefer explicit platform in candidate
                    platform = getattr(cand, 'platform', None) or ( 'OANDA' if '_' in sym else 'COINBASE' if '-' in sym else 'IBKR' )
                    
                    if canary_mode:
                        _canary_log(f"📝 Preparing order: {cand.side} {sym} via {platform}")
                    
                    # Mode-driven routing
                    if chosen == 'simulate':
                        order = engine.place_order(cand, sizing['size'], execution_type='SIMULATED')
                        if canary_mode:
                            _canary_log(f"✅ SIMULATED order placed: {order}")
                    elif chosen == 'oanda-only':
                        if oanda is None:
                            raise RuntimeError('OANDA connector not initialized')
                        units = int(sizing['size']) if isinstance(sizing['size'], (int, float)) else int(float(sizing['size']))
                        order = oanda.place_paper_order(cand, units=units)
                        if canary_mode:
                            _canary_log(f"✅ OANDA paper order placed: {order}")
                    elif chosen == 'coinbase-only':
                        order = coin.place_paper_order(cand, sizing['size'])
                        if canary_mode:
                            _canary_log(f"✅ COINBASE paper order placed: {order}")
                    elif chosen == 'ibkr-only':
                        order = ibkr.place_paper_order(cand, sizing['size'])
                        if canary_mode:
                            _canary_log(f"✅ IBKR paper order placed: {order}")
                    else:
                        # 'auto' or 'platform-paper' behavior: prefer appropriate connector
                        platform = getattr(cand, 'platform', None) or ( 'OANDA' if '_' in sym else 'COINBASE' if '-' in sym else 'IBKR' )
                        if platform == 'OANDA' and oanda is not None:
                            units = int(sizing['size']) if isinstance(sizing['size'], (int, float)) else int(float(sizing['size']))
                            order = oanda.place_paper_order(cand, units=units)
                        elif platform == 'IBKR' and ibkr is not None:
                            order = ibkr.place_paper_order(cand, sizing['size'])
                        else:
                            # default to coin (crypto) or engine fallback
                            try:
                                order = coin.place_paper_order(cand, sizing['size'])
                            except Exception:
                                order = engine.place_order(cand, sizing['size'])
                        if canary_mode:
                            _canary_log(f"✅ AUTO mode order placed via {platform}: {order}")
                except Exception as exc:
                    # Last-resort: simulated engine
                    order = engine.place_order(cand, sizing['size'])
                    print('platform order failed, fell back to engine:', exc)
                    if canary_mode:
                        _canary_log(f"⚠️  Platform order FAILED, engine fallback: {exc}")
                print('placed order:', order)
            
            poll_interval = _get_poll_interval()
            if canary_mode and loop_count % 10 == 0:
                _canary_log(f"😴 Sleeping {poll_interval}s until next check...")
            time.sleep(poll_interval)
    except KeyboardInterrupt:
        print('Headless runner stopped by user')


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description='Headless runner (minimal loop)')
    parser.add_argument('--mode', help='Runner mode (overrides HEADLESS_MODE env var)', choices=['auto','multi-asset','platform-paper','simulate','oanda-only','coinbase-only','ibkr-only'])
    args = parser.parse_args()
    run_headless(mode=args.mode)

